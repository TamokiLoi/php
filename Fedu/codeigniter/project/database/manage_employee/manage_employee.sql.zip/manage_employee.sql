-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2019 at 08:39 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `manage_employee`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `age` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `avatar_image` text COLLATE utf8_unicode_ci NOT NULL,
  `link_fb` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `order_amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `age`, `phone_number`, `avatar_image`, `link_fb`, `order_amount`) VALUES
(1, 'tamoki', '28', '0938947221', 'http://localhost/php/Fedu/codeigniter/manage-employee/FileUpload/3.jpg', 'https://sachvui.com/doc-sach/harry-potter-va-hon-da-phu-thuy-tap-1/chuong-08-bac-thay-doc-duoc.html', '10'),
(2, 'rimoto', '27', '0769988251', 'http://localhost/php/Fedu/codeigniter/manage-employee/FileUpload/3.jpg', 'http://localhost/phpmyadmin/sql.php?db=manage_employee&table=employee&pos=0', '20'),
(3, 'rimoka', '25', '0123456789', 'http://localhost/php/Fedu/codeigniter/manage-employee/FileUpload/3.jpg', 'http://localhost/phpmyadmin/sql.php?db=manage_employee&table=employee&pos=0', '30'),
(4, 'tamoka', '28', '0938947221', 'http://localhost/php/Fedu/codeigniter/manage-employee/FileUpload/3.jpg', 'http://localhost/phpmyadmin/sql.php?db=manage_employee&table=employee&pos=0', '40'),
(5, '11', '11', '11', 'http://localhost/php/Fedu/codeigniter/manage-employee/FileUpload/3.jpg', 'http://localhost/phpmyadmin/sql.php?db=manage_employee&table=employee&pos=0', '11'),
(6, 'Vũ Ngọc Hùng', '30', '0123456789', 'http://localhost/php/Fedu/codeigniter/manage-employee/FileUpload/3.jpg', 'https://vnexpress.net/phap-luat/vks-de-nghi-cho-vo-chong-chu-trung-nguyen-ly-hon-3885991.html', '10'),
(7, 'php', '10', '1000099900', 'http://localhost/php/Fedu/codeigniter/manage-employee/FileUpload/1.png', 'https://drive.google.com/drive/my-drive', '10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
