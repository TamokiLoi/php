-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2019 at 09:56 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `slide_json`
--

-- --------------------------------------------------------

--
-- Table structure for table `homepageattribute`
--

CREATE TABLE `homepageattribute` (
  `id` int(11) NOT NULL,
  `name_att` varchar(255) COLLATE utf32_unicode_ci NOT NULL,
  `value_att` text COLLATE utf32_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `homepageattribute`
--

INSERT INTO `homepageattribute` (`id`, `name_att`, `value_att`) VALUES
(1, 'slide_topbanner', '[{\"title\":\"11\",\"description\":\"22\",\"button_link\":\"33\",\"button_text\":\"44\",\"slide_image\":\"http:\\/\\/localhost\\/php\\/Fedu\\/codeigniter\\/slide-json\\/uploads\\/jpeg2000-home.jpg\"},{\"title\":\"22\",\"description\":\"33\",\"button_link\":\"44\",\"button_text\":\"55\",\"slide_image\":\"http:\\/\\/localhost\\/php\\/Fedu\\/codeigniter\\/slide-json\\/uploads\\/jpegsystems-home.jpg\"},{\"title\":\"33\",\"description\":\"44\",\"button_link\":\"55\",\"button_text\":\"66\",\"slide_image\":\"http:\\/\\/localhost\\/php\\/Fedu\\/codeigniter\\/slide-json\\/uploads\\/Lake_mapourika_NZ.jpeg\"},{\"title\":\"44\",\"description\":\"55\",\"button_link\":\"66\",\"button_text\":\"77\",\"slide_image\":\"http:\\/\\/localhost\\/php\\/Fedu\\/codeigniter\\/slide-json\\/uploads\\/logo-dsm.png\"},{\"title\":\"55\",\"description\":\"66\",\"button_link\":\"77\",\"button_text\":\"88\",\"slide_image\":\"http:\\/\\/localhost\\/php\\/Fedu\\/codeigniter\\/slide-json\\/uploads\\/logo-sol.png\"}]');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `homepageattribute`
--
ALTER TABLE `homepageattribute`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `homepageattribute`
--
ALTER TABLE `homepageattribute`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
