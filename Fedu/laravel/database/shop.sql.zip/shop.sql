-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2019 at 08:23 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `parent` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(79, '2014_10_12_000000_create_users_table', 1),
(80, '2014_10_12_100000_create_password_resets_table', 1),
(81, '2019_03_12_033839_create_categories_table', 1),
(82, '2019_03_12_034359_create_tags_table', 1),
(83, '2019_03_12_034534_create_product_tag_table', 1),
(84, '2019_03_12_034841_create_orders_table', 1),
(85, '2019_03_12_034906_create_product_order_table', 1),
(86, '2019_03_12_043556_create_products_table', 1),
(87, '2019_03_12_064628_table_products_relation', 1),
(88, '2019_03_12_065753_table_product_order_relation', 1),
(89, '2019_03_12_065950_table_product_tag_relation', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `regular_price` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `sale_price` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `original_price` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `attributes` longtext COLLATE utf8mb4_unicode_ci,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_order`
--

CREATE TABLE `product_order` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_tag`
--

CREATE TABLE `product_tag` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'tamoki', 'tamoki1110@gmail.com', '2019-03-12 00:20:30', '$2y$10$aC2IdJATiVYWhjOSgSR7mewyXB0Z8kEWHfrkaMxJCZnQQaOzwUUjK', 'JqI9gEhypc', '2019-03-12 00:20:30', '2019-03-12 00:20:30'),
(2, 'Jude Stanton', 'wiegand.helen@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 't0c7RoWAyX', '2019-03-12 00:20:30', '2019-03-12 00:20:30'),
(3, 'Ilene Baumbach', 'kshields@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'xswjnHdD4u', '2019-03-12 00:20:30', '2019-03-12 00:20:30'),
(4, 'Mrs. Adella Rohan MD', 'dovie71@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'pckSBYFQVc', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(5, 'Mrs. Lue Hickle Sr.', 'antoinette.conroy@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '22UJMVpVX7', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(6, 'Cade Stroman', 'smosciski@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '54krNrkPj5', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(7, 'Filomena McClure', 'goodwin.luther@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '1L8HW51LBj', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(8, 'Savannah Sanford Sr.', 'kamryn.pacocha@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'X79Mrvccpb', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(9, 'Mrs. Gertrude Goldner Jr.', 'ospencer@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 't77IkxH11A', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(10, 'Priscilla Wehner', 'graham.jessica@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '5Zmm4TA7He', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(11, 'Maiya Douglas', 'abigail.barrows@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'shRi1FGMeo', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(12, 'Trevion Tromp', 'craynor@example.com', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'GOdvVH9VMW', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(13, 'Aylin Hand', 'annabelle82@example.com', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '4FqhZlYLZe', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(14, 'Mrs. Bettie Wolff', 'wisozk.paris@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'XBuDikOHye', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(15, 'Lance Lehner', 'ekuhic@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'PBxciu3XVK', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(16, 'Louie Wilderman', 'haleigh.okon@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'knrXRu4KGc', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(17, 'Juwan Flatley', 'miles81@example.com', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'xkNEggqGHW', '2019-03-12 00:20:31', '2019-03-12 00:20:31'),
(18, 'Buster Kozey', 'ignacio26@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'cxwb97wlVX', '2019-03-12 00:20:32', '2019-03-12 00:20:32'),
(19, 'Hermina Zboncak', 'russell45@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'FBeJk5I5N2', '2019-03-12 00:20:32', '2019-03-12 00:20:32'),
(20, 'Trystan Vandervort', 'kherman@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'sKvgds8hfh', '2019-03-12 00:20:32', '2019-03-12 00:20:32'),
(21, 'Tracey Homenick', 'isabella52@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'eMr70iix8j', '2019-03-12 00:20:32', '2019-03-12 00:20:32'),
(22, 'Dr. Tabitha Kihn', 'qlarkin@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0gDiP59f8I', '2019-03-12 00:20:32', '2019-03-12 00:20:32'),
(23, 'Mr. Alejandrin Runte', 'keven.west@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '1e8gJ7VuGJ', '2019-03-12 00:20:32', '2019-03-12 00:20:32'),
(24, 'Mr. Jake Emmerich', 'xoberbrunner@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'yUqEVRgv7q', '2019-03-12 00:20:32', '2019-03-12 00:20:32'),
(25, 'Rowland Kshlerin', 'bernita02@example.com', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'P9Dle7o6PC', '2019-03-12 00:20:32', '2019-03-12 00:20:32'),
(26, 'Rosemary Koelpin II', 'zritchie@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '8COrv9RbZq', '2019-03-12 00:20:32', '2019-03-12 00:20:32'),
(27, 'Kellie Mraz', 'larry15@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'XKhlmFCcsV', '2019-03-12 00:20:33', '2019-03-12 00:20:33'),
(28, 'Marjorie Wilkinson PhD', 'leanna.lockman@example.com', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'JAs7leOaaY', '2019-03-12 00:20:33', '2019-03-12 00:20:33'),
(29, 'Angelita Walter', 'egutmann@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'DjFUnVyYYp', '2019-03-12 00:20:33', '2019-03-12 00:20:33'),
(30, 'Pink Reinger', 'marcus76@example.com', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Hq03N5y3Sh', '2019-03-12 00:20:33', '2019-03-12 00:20:33'),
(31, 'Ubaldo Franecki', 'coty.fahey@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '2NAUnUcU6y', '2019-03-12 00:20:33', '2019-03-12 00:20:33'),
(32, 'Prof. Milford Wunsch DVM', 'schuster.chaz@example.com', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '33sVMlsu9N', '2019-03-12 00:20:33', '2019-03-12 00:20:33'),
(33, 'Mrs. Loma Murray Jr.', 'theo.crist@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vvoBdhJMw5', '2019-03-12 00:20:33', '2019-03-12 00:20:33'),
(34, 'Ms. Adeline Frami IV', 'jasmin27@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'owPfiW853c', '2019-03-12 00:20:33', '2019-03-12 00:20:33'),
(35, 'Mrs. Elenor Brakus DVM', 'wweimann@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'lVYzy2c4Yv', '2019-03-12 00:20:33', '2019-03-12 00:20:33'),
(36, 'Devyn Barrows MD', 'fern76@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jv2TokKAnu', '2019-03-12 00:20:33', '2019-03-12 00:20:33'),
(37, 'Geoffrey Durgan DVM', 'tpacocha@example.com', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'FKbLjy2GuU', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(38, 'Madalyn Corkery Jr.', 'linnie31@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '6zTvl0CyVa', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(39, 'Heidi Mills III', 'hkihn@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'aYT6lws8OO', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(40, 'Devonte O\'Kon', 'hermiston.martine@example.com', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'lTiaR2Hykm', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(41, 'Mr. Mario Bode', 'geovanni.haag@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9IBvOC2Erc', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(42, 'Prof. Bridget Dickinson Jr.', 'nstracke@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '8AnTEQx0Me', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(43, 'Beryl O\'Hara', 'adolph.wintheiser@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'srBiOmpXMB', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(44, 'Charlie Muller V', 'dklocko@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'KeuW0sJIlO', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(45, 'Daphney Towne', 'mstanton@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'BuulVQwCXD', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(46, 'Margie Hansen', 'llangosh@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'q4JF2hU5sP', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(47, 'Janie Kovacek', 'zboncak.rhiannon@example.com', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'gEobnthjKy', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(48, 'Dane Koss', 'annie22@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'GKE4K07PkC', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(49, 'Garnet Hauck', 'julian.schoen@example.org', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'asUk9rh55X', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(50, 'Mr. Lester Koepp', 'callie41@example.com', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'TUHX9M0twr', '2019-03-12 00:20:34', '2019-03-12 00:20:34'),
(51, 'Leopoldo Howe', 'wisozk.freeda@example.net', '2019-03-12 00:20:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'NBkaggZ15T', '2019-03-12 00:20:34', '2019-03-12 00:20:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_name_unique` (`name`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_code_unique` (`code`),
  ADD KEY `products_category_id_foreign` (`category_id`),
  ADD KEY `products_user_id_foreign` (`user_id`);

--
-- Indexes for table `product_order`
--
ALTER TABLE `product_order`
  ADD KEY `product_order_product_id_foreign` (`product_id`),
  ADD KEY `product_order_order_id_foreign` (`order_id`);

--
-- Indexes for table `product_tag`
--
ALTER TABLE `product_tag`
  ADD KEY `product_tag_product_id_foreign` (`product_id`),
  ADD KEY `product_tag_tag_id_foreign` (`tag_id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tags_name_unique` (`name`),
  ADD UNIQUE KEY `tags_slug_unique` (`slug`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `products_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_order`
--
ALTER TABLE `product_order`
  ADD CONSTRAINT `product_order_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_order_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_tag`
--
ALTER TABLE `product_tag`
  ADD CONSTRAINT `product_tag_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_tag_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
